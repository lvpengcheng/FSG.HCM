namespace MyCompanyName.MyProjectName.MyModuleName
{
    public class MyModuleNameDomainAutoMapperProfile : Profile
    {
        public MyModuleNameDomainAutoMapperProfile()
        {
        }
    }
}