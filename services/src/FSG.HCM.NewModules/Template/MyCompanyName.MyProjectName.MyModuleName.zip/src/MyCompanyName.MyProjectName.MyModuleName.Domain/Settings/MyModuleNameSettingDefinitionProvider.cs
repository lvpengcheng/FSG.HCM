namespace MyCompanyName.MyProjectName.MyModuleName.Settings
{
    public class MyModuleNameSettingDefinitionProvider : SettingDefinitionProvider
    {
        public override void Define(ISettingDefinitionContext context)
        {
            /* Define module settings here.
             * Use names from MyModuleNameSettings class.
             */
        }
    }
}