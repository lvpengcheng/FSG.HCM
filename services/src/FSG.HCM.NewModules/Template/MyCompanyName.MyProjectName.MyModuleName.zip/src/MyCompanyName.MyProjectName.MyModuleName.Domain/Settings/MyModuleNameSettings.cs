namespace MyCompanyName.MyProjectName.MyModuleName.Settings
{
    public static class MyModuleNameSettings
    {
        public const string GroupName = "MyModuleName";

        /* Add constants for setting names. Example:
         * public const string MySettingName = GroupName + ".MySettingName";
         */
    }
}