// Global using directives

global using Microsoft.Extensions.DependencyInjection;
global using Volo.Abp.Http.Client;
global using Volo.Abp.Modularity;