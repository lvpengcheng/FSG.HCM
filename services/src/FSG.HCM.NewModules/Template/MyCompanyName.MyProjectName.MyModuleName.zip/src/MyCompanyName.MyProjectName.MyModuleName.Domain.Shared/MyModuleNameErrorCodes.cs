namespace MyCompanyName.MyProjectName.MyModuleName
{
    public static class MyModuleNameErrorCodes
    {

    }
}
