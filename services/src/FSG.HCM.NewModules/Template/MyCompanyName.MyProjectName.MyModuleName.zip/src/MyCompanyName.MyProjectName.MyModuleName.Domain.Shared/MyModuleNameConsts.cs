namespace MyCompanyName.MyProjectName.MyModuleName
{
    public  class MyModuleNameConsts
    {
        /// <summary>名称空间</summary>
        public const string NameSpace = "MyCompanyName.MyProjectName.MyModuleName";
        /// <summary>默认语言</summary>
        public const string DefaultCultureName = "zh-Hans";
    }
}