namespace MyCompanyName.MyProjectName.MyModuleName.Localization
{
    [LocalizationResourceName("MyModuleName")]
    public class MyModuleNameResource
    {
        
    }
}
